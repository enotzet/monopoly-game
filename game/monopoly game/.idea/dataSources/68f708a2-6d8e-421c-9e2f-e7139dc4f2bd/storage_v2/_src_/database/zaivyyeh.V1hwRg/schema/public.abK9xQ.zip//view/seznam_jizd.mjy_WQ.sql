create view seznam_jízd
            (id_jízdy, id_ridice, id_zakaznika, cena, vzdalenost, doba_trvání, jmeno_řidiče, příjmení_řidiče,
             jmeno_zakaznika, příjmení_zakaznika)
as
SELECT j."id_jízdy",
       j.id_ridice,
       j.id_zakaznika,
       j.cena,
       j.vzdalenost,
       j."doba_trvání",
       u.jmeno      AS "jmeno_řidiče",
       u."příjmení" AS "příjmení_řidiče",
       z.jmeno      AS jmeno_zakaznika,
       z."příjmení" AS "příjmení_zakaznika"
FROM "jízda" j
         LEFT JOIN "uživatel" u ON j.id_ridice = u.id
         LEFT JOIN "uživatel" z ON j.id_zakaznika = z.id;

alter table seznam_jízd
    owner to zaivyyeh;

