create function aktualizace_počtu_jízd() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE Zákazník
        SET počet_jízd = počet_jízd + 1
        WHERE id_uživatele = NEW.id_zakaznika;
    END IF;
    RETURN NEW;
END;
$$;

alter function aktualizace_počtu_jízd() owner to zaivyyeh;

